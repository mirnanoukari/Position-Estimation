# Keypoints > 2022-11-23 4:26pm
https://universe.roboflow.com/keypoints-detection/keypoints-5vjbh

Provided by a Roboflow user
License: CC BY 4.0

